1. Paste the L4.txt in the same directory.
2. Run program.sh in terminal by typing: "sh program.sh"
3. Time taken to generate all output can be measure by "time sh program.sh" which should be less than 2 min (depends on the system)

4. Our group consists of Gopal Krishan Aggarwal(myself), B13121 and Tushar Gupta, B13235 and we have each made separate code for most of the subproblems.